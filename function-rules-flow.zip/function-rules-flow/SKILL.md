---
name: function-rules-flow
description: "Guidance and reference for X/Twitter Digest 功能 / 规则 / 流程说明. Use when a request involves x/Twitter Digest 功能 / 规则 / 流程说明 or needs the procedures and examples documented in this source."
---

# X/Twitter Digest 功能 / 规则 / 流程说明

面向 PM/用户的完整运行流程说明见：

```text
twitter-digest/RUNBOOK.md
```

## 1. 功能

`twitter-digest` 默认 `--source auto`：已配置 API 时通过 API 读取公开数据并生成中文日报；未配置 API 时使用浏览器采集。API 已配置但认证失效时，会先触发 API 重配置，配置成功后继续 API 采集。用户主动要求浏览器或显式传入 `--source browser` 时强制浏览器。

采集内容按来源区分：

- Home timeline：时间线热点
- Mentions search：搜索谁 @ 了当前账号
- Own profile：当前账号主页动态
- API 模式：公开数据为主，包括 home timeline、mentions / @ 搜索、own profile；不以 DM 作为日报依据。
- 浏览器模式：包含 home timeline、mentions search、mentions notifications、own profile，以及私信页面可见会话。

默认不采集关键词。只有显式传 `--keywords` 时才做关键词搜索。

公开页采集范围：

- timeline、profile、mentions 默认按日报目标加载近 24 小时内容。
- API public 默认最多保留 300 条公开帖子；浏览器公开页默认最多滚动 40 次，并最多保留 100 条公开帖子进入 `digest-context`。
- 如果已加载帖子的时间戳显示已经超过 24 小时窗口，会提前停止滚动。
- 公开帖子数量表示“本次浏览器加载到的帖子”，不是完整 X 历史。

## 2. 数据保存位置

安装脚本会按当前工具选择 skills 目录：Codex 使用 `~/.codex/skills`，Claude Code 使用 `~/.claude/skills`。旧的 `twitter-briefing`、`twitter-briefing.bak` 或已有 `twitter-digest` 安装会迁移到所选 skills 目录的 `.backups/`，并把备份里的 `SKILL.md` 改成 `SKILL.md.disabled`，避免当前工具加载重复旧 skill。

登录状态保存在：

```text
twitter-digest/.state/chrome-profile
```

这不是 `/tmp`。只要这个目录不删除、X 登录态不过期，后续运行会复用。

每次运行的临时采集结果保存在：

```text
twitter-digest/.state/run/
```

主要文件：

```text
twitter-digest/.state/run/digest-input.json
twitter-digest/.state/run/digest-input.md
twitter-digest/.state/run/digest-context.json
twitter-digest/.state/run/digest-context.md
```

用途：

- `digest-context.md/json`：最终总结主输入，包含本次采集归一化后的 `Final Summary Facts`。
- `digest-input.md/json`：原始采集结果，只在需要核对细节或排查抓取问题时使用。

不生成长期 `memory.json`，不生成 `daily/` 历史归档。
`twitter-digest/.state/run/` 会尽量设置为 700 权限，避免把当次 DM 原文放到全局可读的 `/tmp`。

## 3. 运行规则

- 默认入口 `run_daily_digest.py`：自动选择来源。已配置 API 时走 API；未配置 API 时走浏览器；API 已配置但认证失效时自动进入配置流程，配置成功后继续 API 采集。
- 用户主动要求浏览器或命令显式 `--source browser` 时强制浏览器；API 模式只抓公开数据，不打开浏览器。
- DM / X Chat 以本地浏览器抓取为准；API 模式不用于判断是否有私信。
- API 认证类错误会触发一次重配；权限不足、tier 不支持、限流或其他 API 错误记录数据缺口或失败，不回退浏览器路径。
- 不要求用户复制 cookie 或 token。
- 默认 headless 运行。
- 第一次没有登录态时，会自动打开可见浏览器让用户登录。
- 浏览器模式默认读取 DM，但只读取浏览器页面上可见的内容；API 模式不以 DM 作为日报依据。
- 支持 `--non-interactive`，定时任务遇到 passcode 时跳过 DM 恢复并记录数据缺口，不阻塞等待。
- 不自动发送消息、回复、点赞、关注、拉黑、打开可疑链接或接受 DM 请求。
- 只生成摘要和建议回复草稿。
- DM 原文只用于当次总结，不写入长期状态文件。

## 4. 首次运行流程

1. 用户运行：

   ```bash
   python3 twitter-digest/scripts/run_daily_digest.py
   ```

2. 脚本检查 API 配置；如果缺失，走浏览器；如果已配置但认证失效，打开 API 重配置流程。

3. 用户在配置流程里输入 Client ID / Secret 并完成 X OAuth 授权。

4. 脚本保存并验证 API 配置。

5. 脚本继续用 API 采集 timeline、mentions、own profile 等公开数据。

如果用户显式使用 `--source browser`：

1. 脚本先尝试用 headless 浏览器读取保存的登录态。
2. 如果没有登录态，脚本自动打开可见浏览器窗口。
3. 用户在该浏览器窗口里登录 X。
4. 脚本自动识别当前 X 账号 handle；如果 headless 识别失败，会打开可见浏览器重试。
5. 如果仍无法识别 handle，脚本直接停止并要求用户带 `--handle <用户名>` 重跑，不能生成缺 `@你` 和自己动态的日报。
6. 识别成功后，脚本采集 timeline、mentions、own profile、DM。

9. 脚本生成 `twitter-digest/.state/run/*` 当次采集文件。

10. Agent 只读取 `twitter-digest/.state/run/digest-context.md` 生成中文日报。

11. `digest-input.*` 只在排查抓取问题时使用。

## 5. 后续运行流程

1. 用户再次运行：

   ```bash
   python3 twitter-digest/scripts/run_daily_digest.py
   ```

2. 脚本默认 headless 启动。

3. 脚本复用：

   ```text
   twitter-digest/.state/chrome-profile
   ```

4. 如果登录态有效，不弹浏览器窗口。

5. 脚本直接采集并生成日报输入文件。

6. Agent 生成中文日报。

## 6. 需要人工介入的情况

以下情况会打开可见浏览器窗口：

- 第一次使用，还没有登录态。
- X session 过期。
- 用户退出了 X。
- X 要求 CAPTCHA 或风控验证。
- X Chat 要求设置或输入 passcode，此时会自动打开可见浏览器窗口，等待用户处理后继续。
- `twitter-digest/.state/chrome-profile` 被删除。

## 7. DM 规则

DM 默认读取。

读取范围：

- 只读 X Messages 通过浏览器加载出来的内容；打开等我回复会话后会自动向上滚动加载更多消息。
- 默认先向下扫描 X Chat 左侧会话列表，最多 20 轮，尽量覆盖今天的可见会话，而不是只看首屏。
- 只统计今天可见会话数量、最后我发出的数量、等我回复的数量；列表里更早的历史会话不计入日报会话数。
- “最后我发出”只看 X Chat 列表最后预览是否是 `You:` / `You sent` / `你:`，不是指会话历史里曾经回复过。
- 消息数量单独统计，只来自已打开的等我回复会话里的消息气泡，不能和会话数量混用。
- 默认每个等我回复会话会尽量向上滚到对话顶部，完整捕获浏览器可加载的会话历史。
- 默认安全上限是向上滚动 200 次，并最多保留 2000 条消息气泡；`--dm-window-hours 0` 表示不按 24 小时窗口截断 DM 历史。
- 如果没有滚到顶部或命中消息上限，会在 `digest-context` 的数据缺口里记录 `dm_thread_incomplete`，不能假装完整。
- 如果会话列表没有扫到底，会在 `digest-context` 的数据缺口里记录 `dm_list_incomplete`，日报需要说明可能还有会话未覆盖。
- 如果 X Messages 显示骨架屏、占位条或右侧 `Start Conversation` 但左侧会话列表仍未真实加载，脚本会自动重载 `/messages`，最多重试 3 次；仍失败时记录 `dm_page_loading_timeout`，不能写成“没有私信”。
- `digest-context.md` 会为需要总结的等我回复会话输出 `DM Thread Context`，最多带 2000 条已加载消息，并保留 raw label、URL、加载状态等原始信息，方便模型理解复杂上下文。
- 默认只打开今天等我回复的会话。
- 发信人以 `participant` / `会话对象` 和消息气泡方向为准，不能把引用帖、转发卡片、链接预览里的作者当作 DM 发信人。
- 如果今天可见会话最后一条都是我发出的，会记录 `no_unreplied_threads`，日报应写“今天可见私信会话最后一条都是我发出的，无需处理”，不能写“没有私信”。
- 如果能看到会话列表但打不开等我回复的正文，会记录 `visible_threads_unopened`。
- 只有 `captured_unreplied_threads` 的私信，才进入 DM 摘要。
- 等我回复的私信也要挑重点总结；垃圾、钓鱼、低质营销、重复无关内容只计数并归为忽略，不要展开正文。
- 如果 inbox 为空，会记录 `no_visible_threads`。
- 如果 X Chat 要求 passcode，headless 会自动切到可见浏览器窗口，等待用户输入或完成设置后重试 DM 采集。

隐私规则：

- 不长期保存 DM 原文。
- 不写 `memory.json`。
- 不写 `daily/` 历史归档。
- 不保存 DM thread 状态签名。

不保存：

- DM 原文
- X cookie
- token
- passcode
- 浏览器截图

## 8. 常用命令

生成今日 X 日报：

```bash
python3 twitter-digest/scripts/run_daily_digest.py
```

跳过 DM：

```bash
python3 twitter-digest/scripts/run_daily_digest.py --source browser --no-dms
```

强制显示浏览器窗口：

```bash
python3 twitter-digest/scripts/run_daily_digest.py --source browser --headed
```

无人值守定时运行：

```bash
python3 twitter-digest/scripts/run_daily_digest.py --non-interactive
```

增加滚动覆盖：

```bash
python3 twitter-digest/scripts/run_daily_digest.py --source browser --scrolls 5
```

增加关键词搜索：

```bash
python3 twitter-digest/scripts/run_daily_digest.py --keywords "AI,crypto"
```

清理登录状态并重新登录：

```bash
rm -rf twitter-digest/.state/chrome-profile
```

## 10. 预期日报结构

日报默认用中文输出：

```markdown
## 🐦 X 日报 - YYYY-MM-DD

**📌 今日总结**

**✅ 该处理**

**◆ 谁 @ 了你**

**◆ 私信（DM）**

**◆ 时间线热点**

**◆ 你的动态**

**✍️ 建议回复草稿**

**⚠️ 数据缺口**
```
