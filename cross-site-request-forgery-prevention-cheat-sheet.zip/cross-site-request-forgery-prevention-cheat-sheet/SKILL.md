---
name: cross-site-request-forgery-prevention-cheat-sheet
description: "Guidance and reference for Cross-Site Request Forgery Prevention Cheat Sheet. Use when a request involves cross-Site Request Forgery Prevention Cheat Sheet or needs the procedures and examples documented in this source."
---

# Cross-Site Request Forgery Prevention Cheat Sheet

A [Cross-Site Request Forgery (CSRF)](https://owasp.org/www-community/attacks/csrf) attack occurs when a malicious web site, email, blog, instant message, or program tricks an authenticated user's web browser into performing an unwanted action on a trusted site. If a target user is authenticated to the site, unprotected target sites cannot distinguish between legitimate authorized requests and forged authenticated requests.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Cross-Site Request Forgery Prevention Cheat Sheet.
