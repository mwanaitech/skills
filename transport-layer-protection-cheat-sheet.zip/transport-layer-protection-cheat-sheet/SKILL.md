---
name: transport-layer-protection-cheat-sheet
description: "Guidance and reference for DEPRECATED: Transport Layer Protection Cheat Sheet. Use when a request involves dEPRECATED: Transport Layer Protection Cheat Sheet or needs the procedures and examples documented in this source."
---

# DEPRECATED: Transport Layer Protection Cheat Sheet

The Transport Layer Protection Cheat Sheet has been deprecated.

Please visit the [Transport Layer Security Cheat Sheet](Transport_Layer_Security_Cheat_Sheet.md) instead.
