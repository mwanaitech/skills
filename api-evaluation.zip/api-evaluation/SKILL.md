---
name: api-evaluation
description: "Guidance and reference for API Evaluation. Use when a request involves aPI Evaluation or needs the procedures and examples documented in this source."
---

# API Evaluation

Guide to evaluating OpenAI, Anthropic, and other API-based language models.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving API Evaluation.
