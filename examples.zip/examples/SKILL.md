---
name: examples
description: "Guidance and reference for Seaborn Common Use Cases and Examples. Use when a request involves seaborn Common Use Cases and Examples or needs the procedures and examples documented in this source."
---

# Seaborn Common Use Cases and Examples

This document provides practical examples for common data visualization scenarios using seaborn.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Seaborn Common Use Cases and Examples.
