---
name: python-flask-web-server-security
description: "Guidance and reference for Flask (Python) Web Security Spec (Flask 3.1.x, Python 3.x). Use when a request involves flask (Python) Web Security Spec (Flask 3.1.x, Python 3.x) or needs the procedures and examples documented in this source."
---

# Flask (Python) Web Security Spec (Flask 3.1.x, Python 3.x)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Flask (Python) Web Security Spec (Flask 3.1.x, Python 3.x).
