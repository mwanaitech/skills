---
name: citation-workflow
description: "Guidance and reference for Citation Management & Hallucination Prevention. Use when a request involves citation Management & Hallucination Prevention or needs the procedures and examples documented in this source."
---

# Citation Management & Hallucination Prevention

This reference provides a complete workflow for managing citations programmatically, preventing AI-generated citation hallucinations, and maintaining clean bibliographies.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Citation Management & Hallucination Prevention.
