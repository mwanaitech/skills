---
name: benchmark-checklist
description: "Guidance and reference for CIS GCP Foundation Benchmark v2.0.0 -- Detailed Checklist. Use when a request involves cIS GCP Foundation Benchmark v2.0.0 -- Detailed Checklist or needs the procedures and examples documented in this source."
---

# CIS GCP Foundation Benchmark v2.0.0 -- Detailed Checklist

This file contains the detailed CIS benchmark checklist items for the GCP Security Posture Review skill. See [SKILL.md](SKILL.md) for the main skill definition, process overview, and output format.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving CIS GCP Foundation Benchmark v2.0.0 -- Detailed Checklist.
