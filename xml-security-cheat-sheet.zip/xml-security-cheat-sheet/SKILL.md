---
name: xml-security-cheat-sheet
description: "Guidance and reference for XML Security Cheat Sheet. Use when a request involves xML Security Cheat Sheet or needs the procedures and examples documented in this source."
---

# XML Security Cheat Sheet

While the specifications for XML and XML schemas provide you with the tools needed to protect XML applications, they also include multiple security flaws. They can be exploited to perform multiple types of attacks, including file retrieval, server side request forgery, port scanning, and brute forcing. This cheat sheet will make you aware of how attackers can exploit the different possibilities in XML used in libraries and software using two possible attack surfaces:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving XML Security Cheat Sheet.
