---
name: multifactor-authentication-cheat-sheet
description: "Guidance and reference for Multifactor Authentication Cheat Sheet. Use when a request involves multifactor Authentication Cheat Sheet or needs the procedures and examples documented in this source."
---

# Multifactor Authentication Cheat Sheet

Multifactor Authentication (MFA) or Two-Factor Authentication (2FA) is when a user is required to present more than one type of evidence in order to authenticate on a system. There are five different types of evidence (or factors) and any combination of these can be used, however in practice only the first three are common in web applications. The five types are as follows:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Multifactor Authentication Cheat Sheet.
