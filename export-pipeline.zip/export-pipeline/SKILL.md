---
name: export-pipeline
description: "Guidance and reference for Export Pipeline. Use when a request involves export Pipeline or needs the procedures and examples documented in this source."
---

# Export Pipeline

For resolutions beyond screen size, use `pixelDensity()` or a large offscreen buffer:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Export Pipeline.
