---
name: monogram-patterns
description: "Guidance and reference for Monogram Favicon Patterns. Use when a request involves monogram Favicon Patterns or needs the procedures and examples documented in this source."
---

# Monogram Favicon Patterns

Comprehensive guide for creating text-based favicons when no logo icon exists.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Monogram Favicon Patterns.
