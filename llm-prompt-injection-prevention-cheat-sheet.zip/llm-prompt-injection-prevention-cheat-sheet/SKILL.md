---
name: llm-prompt-injection-prevention-cheat-sheet
description: "Guidance and reference for LLM Prompt Injection Prevention Cheat Sheet. Use when a request involves lLM Prompt Injection Prevention Cheat Sheet or needs the procedures and examples documented in this source."
---

# LLM Prompt Injection Prevention Cheat Sheet

Prompt injection is a vulnerability in Large Language Model (LLM) applications that allows attackers to manipulate the model's behavior by injecting malicious input that changes its intended output. Unlike traditional injection attacks, prompt injection exploits the common design of most LLMs where natural language instructions and data are processed together without clear separation.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving LLM Prompt Injection Prevention Cheat Sheet.
