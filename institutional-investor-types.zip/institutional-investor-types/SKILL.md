---
name: institutional-investor-types
description: "Guidance and reference for Institutional Investor Types and Strategies. Use when a request involves institutional Investor Types and Strategies or needs the procedures and examples documented in this source."
---

# Institutional Investor Types and Strategies

Not all institutional investors are created equal. Understanding the different types of institutions, their investment strategies, time horizons, and motivations is critical for interpreting 13F filing changes. This guide categorizes institutional investors and explains how to weight their buy/sell signals.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Institutional Investor Types and Strategies.
