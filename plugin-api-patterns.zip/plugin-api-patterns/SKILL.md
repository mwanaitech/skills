---
name: plugin-api-patterns
description: "Guidance and reference for Plugin API Patterns. Use when a request involves plugin API Patterns or needs the procedures and examples documented in this source."
---

# Plugin API Patterns

Page context resets between `use_figma` calls — `figma.currentPage` always starts on the first page. Use `await figma.setCurrentPageAsync(page)` at the start of each invocation to switch to the correct page.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Plugin API Patterns.
