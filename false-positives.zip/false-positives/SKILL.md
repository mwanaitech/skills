---
name: false-positives
description: "Guidance and reference for False Positives Guide. Use when a request involves false Positives Guide or needs the procedures and examples documented in this source."
---

# False Positives Guide

When validation warnings are acceptable and how to handle them.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving False Positives Guide.
