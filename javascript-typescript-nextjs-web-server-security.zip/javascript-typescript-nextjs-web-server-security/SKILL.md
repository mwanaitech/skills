---
name: javascript-typescript-nextjs-web-server-security
description: "Guidance and reference for Next.js (TypeScript/JavaScript) Web Security Spec (Next.js 16.1.x, Node.js 20.9+). Use when a request involves next.js (TypeScript/JavaScript) Web Security Spec (Next.js 16.1.x, Node.js 20.9+) or needs the procedures and examples documented in this source."
---

# Next.js (TypeScript/JavaScript) Web Security Spec (Next.js 16.1.x, Node.js 20.9+)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Next.js (TypeScript/JavaScript) Web Security Spec (Next.js 16.1.x, Node.js 20.9+).
