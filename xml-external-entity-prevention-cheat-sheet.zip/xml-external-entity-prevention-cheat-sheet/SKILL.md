---
name: xml-external-entity-prevention-cheat-sheet
description: "Guidance and reference for XML External Entity Prevention Cheat Sheet. Use when a request involves xML External Entity Prevention Cheat Sheet or needs the procedures and examples documented in this source."
---

# XML External Entity Prevention Cheat Sheet

An *XML eXternal Entity injection* (XXE), which is now part of the [OWASP Top 10](https://owasp.org/www-project-top-ten/OWASP_Top_Ten_2017/Top_10-2017_A4-XML_External_Entities_%28XXE%29) via the point **A4**, is attack against applications that parse XML input. This issue is referenced in the ID [611](https://cwe.mitre.org/data/definitions/611.html) in the [Common Weakness Enumeration](https://cwe.mitre.org/index.html) referential. An XXE attack occurs when untrusted XML input with a **reference to an external entity is processed by a weakly configured XML parser**, and this attack could be used to stage multiple incidents, including:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving XML External Entity Prevention Cheat Sheet.
