---
name: mapping-checklist
description: "Guidance and reference for Code Connect Mapping Checklist. Use when a request involves code Connect Mapping Checklist or needs the procedures and examples documented in this source."
---

# Code Connect Mapping Checklist

- Confirm Figma component is published
- Convert URL node-id (`-`) to tool nodeId (`:`)
- Check existing mappings first
- Compare props/variants between design and code
- Ask for confirmation when multiple matches are plausible
