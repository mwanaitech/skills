---
name: javascript-general-web-frontend-security
description: "Guidance and reference for Frontend JavaScript/TypeScript Web Security Spec (Vanilla Browser JS/TS, Modern Browsers). Use when a request involves frontend JavaScript/TypeScript Web Security Spec (Vanilla Browser JS/TS, Modern Browsers) or needs the procedures and examples documented in this source."
---

# Frontend JavaScript/TypeScript Web Security Spec (Vanilla Browser JS/TS, Modern Browsers)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Frontend JavaScript/TypeScript Web Security Spec (Vanilla Browser JS/TS, Modern Browsers).
