---
name: pitfalls
description: "Guidance and reference for TouchDesigner MCP — Pitfalls & Lessons Learned. Use when a request involves touchDesigner MCP — Pitfalls & Lessons Learned or needs the procedures and examples documented in this source."
---

# TouchDesigner MCP — Pitfalls & Lessons Learned

Hard-won knowledge from real TD sessions. Read this before building anything.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving TouchDesigner MCP — Pitfalls & Lessons Learned.
