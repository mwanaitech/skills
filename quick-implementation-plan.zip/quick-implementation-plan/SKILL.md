---
name: quick-implementation-plan
description: "Guidance and reference for Quick Implementation Plan Template. Use when a request involves quick Implementation Plan Template or needs the procedures and examples documented in this source."
---

# Quick Implementation Plan Template

For simpler features or small changes.

```markdown
# Implementation: [Feature Name]

## Spec
<mention-page url="...">Specification</mention-page>

## Summary
[Quick description]

## Tasks
- [ ] <mention-page url="...">Task 1</mention-page>
- [ ] <mention-page url="...">Task 2</mention-page>
- [ ] <mention-page url="...">Task 3</mention-page>

## Timeline
Start: [Date]
Target completion: [Date]

## Status
[Update as work progresses]
```
