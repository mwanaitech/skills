---
name: target-allocations
description: "Guidance and reference for Target Allocation Models. Use when a request involves target Allocation Models or needs the procedures and examples documented in this source."
---

# Target Allocation Models

This document provides model portfolio allocations for different investor risk profiles, serving as benchmarks for portfolio analysis and rebalancing.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Target Allocation Models.
