---
name: asset-allocation
description: "Guidance and reference for Asset Allocation Framework. Use when a request involves asset Allocation Framework or needs the procedures and examples documented in this source."
---

# Asset Allocation Framework

This document provides comprehensive guidance on asset allocation principles, target allocations by risk profile, and rebalancing triggers for portfolio management.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Asset Allocation Framework.
