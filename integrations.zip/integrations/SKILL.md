---
name: integrations
description: "Guidance and reference for Framework Integrations Guide. Use when a request involves framework Integrations Guide or needs the procedures and examples documented in this source."
---

# Framework Integrations Guide

Complete guide to integrating W&B with popular ML frameworks.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Framework Integrations Guide.
