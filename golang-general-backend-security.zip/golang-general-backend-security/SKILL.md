---
name: golang-general-backend-security
description: "Guidance and reference for Go (Golang) Security Spec (Go 1.25.x, Standard Library, net/http). Use when a request involves go (Golang) Security Spec (Go 1.25.x, Standard Library, net/http) or needs the procedures and examples documented in this source."
---

# Go (Golang) Security Spec (Go 1.25.x, Standard Library, net/http)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Go (Golang) Security Spec (Go 1.25.x, Standard Library, net/http).
