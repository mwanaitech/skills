---
name: dom-based-xss-prevention-cheat-sheet
description: "Guidance and reference for DOM based XSS Prevention Cheat Sheet. Use when a request involves dOM based XSS Prevention Cheat Sheet or needs the procedures and examples documented in this source."
---

# DOM based XSS Prevention Cheat Sheet

When looking at XSS (Cross-Site Scripting), there are three generally recognized forms of [XSS](https://owasp.org/www-community/attacks/xss/):

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving DOM based XSS Prevention Cheat Sheet.
