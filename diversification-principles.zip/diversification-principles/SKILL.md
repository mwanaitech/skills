---
name: diversification-principles
description: "Guidance and reference for Diversification Principles. Use when a request involves diversification Principles or needs the procedures and examples documented in this source."
---

# Diversification Principles

This document explains the theory and practice of portfolio diversification, providing frameworks for assessing diversification quality and identifying concentration risks.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Diversification Principles.
