---
name: logging-vocabulary-cheat-sheet
description: "Guidance and reference for Application Logging Vocabulary Cheat Sheet. Use when a request involves application Logging Vocabulary Cheat Sheet or needs the procedures and examples documented in this source."
---

# Application Logging Vocabulary Cheat Sheet

This document proposes a standard vocabulary for logging security events. The intent is to simplify monitoring and alerting such that, assuming developers trap errors and log them using this vocabulary, monitoring and alerting would be improved by simply keying on these terms.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Application Logging Vocabulary Cheat Sheet.
