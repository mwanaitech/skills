---
name: email-professionnel-base
description: "Guide et références sur Email Professionnel Base. À utiliser pour les demandes portant sur email Professionnel Base ou nécessitant les procédures et exemples de cette source."
---

# Email Professionnel Base

Objet : [SUJET CONCIS ET CLAIR]

Madame, Monsieur,

[Contexte en 1 phrase : faire référence à l'échange ou au document précédent]

[Demande principale ou information claire en 2-3 phrases maximum]

[Action attendue de la part du destinataire, avec échéance si nécessaire]

Je reste disponible pour [préciser : un appel, des précisions, une réunion].

Cordialement,

HANS AXEL MBINA MABICKA
hansaxel25@gmail.com
+241 74 64 10 29 / +241 65 05 37 32
linkedin.com/in/hans-axel
mwana-itech.pages.dev
Libreville, Gabon
