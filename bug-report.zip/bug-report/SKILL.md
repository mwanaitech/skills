---
name: bug-report
description: "Guidance and reference for Bug Description. Use when a request involves bug Description or needs the procedures and examples documented in this source."
---

## Bug Description

<!-- Clear, concise description of the bug -->

## Steps to Reproduce

1.
2.
3.

## Expected Behavior

<!-- What should happen -->

## Actual Behavior

<!-- What actually happens -->

## Environment

- OS:
- Version/Commit:
- Python version:
- Browser (if applicable):

## Error Output

<!-- Paste relevant error messages, stack traces, or logs -->

```
```

## Additional Context

<!-- Screenshots, related issues, workarounds discovered, etc. -->
