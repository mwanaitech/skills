---
name: benchmark-guide
description: "Guidance and reference for Benchmark Guide. Use when a request involves benchmark Guide or needs the procedures and examples documented in this source."
---

# Benchmark Guide

Complete guide to all 60+ evaluation tasks in lm-evaluation-harness, what they measure, and how to interpret results.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Benchmark Guide.
