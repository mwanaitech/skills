---
name: error-catalog
description: "Guidance and reference for Error Catalog. Use when a request involves error Catalog or needs the procedures and examples documented in this source."
---

# Error Catalog

Comprehensive catalog of n8n validation errors with real examples and fixes.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Error Catalog.
