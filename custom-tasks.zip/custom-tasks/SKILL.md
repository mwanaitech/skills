---
name: custom-tasks
description: "Guidance and reference for Custom Tasks. Use when a request involves custom Tasks or needs the procedures and examples documented in this source."
---

# Custom Tasks

Complete guide to creating domain-specific evaluation tasks in lm-evaluation-harness.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Custom Tasks.
