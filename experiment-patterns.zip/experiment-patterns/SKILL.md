---
name: experiment-patterns
description: "Guidance and reference for Experiment Design Patterns. Use when a request involves experiment Design Patterns or needs the procedures and examples documented in this source."
---

# Experiment Design Patterns

Patterns and best practices distilled from running research experiments at scale with the Hermes agent. These cover experiment infrastructure, evaluation protocols, monitoring, and failure recovery.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Experiment Design Patterns.
