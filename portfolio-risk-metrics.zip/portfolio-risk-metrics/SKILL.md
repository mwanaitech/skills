---
name: portfolio-risk-metrics
description: "Guidance and reference for Portfolio Risk Metrics. Use when a request involves portfolio Risk Metrics or needs the procedures and examples documented in this source."
---

# Portfolio Risk Metrics

This document provides comprehensive guidance on measuring and interpreting portfolio risk using standard financial metrics.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Portfolio Risk Metrics.
