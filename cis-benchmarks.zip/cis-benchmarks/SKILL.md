---
name: cis-benchmarks
description: "Guidance and reference for Docker and Kubernetes CIS Benchmark Details. Use when a request involves docker and Kubernetes CIS Benchmark Details or needs the procedures and examples documented in this source."
---

# Docker and Kubernetes CIS Benchmark Details

This file contains the detailed CIS Docker Benchmark v1.6.0, CIS Kubernetes Benchmark v1.9.0, and NIST SP 800-190 checklist items for the Container & Kubernetes Security Review skill. See [SKILL.md](SKILL.md) for the main skill definition, process overview, and output format.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Docker and Kubernetes CIS Benchmark Details.
