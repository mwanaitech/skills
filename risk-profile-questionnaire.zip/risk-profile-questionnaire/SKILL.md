---
name: risk-profile-questionnaire
description: "Guidance and reference for Risk Profile Questionnaire. Use when a request involves risk Profile Questionnaire or needs the procedures and examples documented in this source."
---

# Risk Profile Questionnaire

This document provides a framework for assessing investor risk tolerance and determining appropriate target asset allocation.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Risk Profile Questionnaire.
