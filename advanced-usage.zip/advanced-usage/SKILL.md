---
name: advanced-usage
description: "Guidance and reference for Segment Anything Advanced Usage Guide. Use when a request involves segment Anything Advanced Usage Guide or needs the procedures and examples documented in this source."
---

# Segment Anything Advanced Usage Guide

SAM 2 extends SAM to video segmentation with streaming memory architecture:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Segment Anything Advanced Usage Guide.
