---
name: dotnet-security-cheat-sheet
description: "Guidance and reference for DotNet Security Cheat Sheet. Use when a request involves dotNet Security Cheat Sheet or needs the procedures and examples documented in this source."
---

# DotNet Security Cheat Sheet

This page intends to provide quick basic .NET security tips for developers.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving DotNet Security Cheat Sheet.
