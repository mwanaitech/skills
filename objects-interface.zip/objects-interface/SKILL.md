---
name: objects-interface
description: "Guidance and reference for Seaborn Objects Interface. Use when a request involves seaborn Objects Interface or needs the procedures and examples documented in this source."
---

# Seaborn Objects Interface

The `seaborn.objects` interface provides a modern, declarative API for building visualizations through composition. This guide covers the objects interface introduced in seaborn 0.12+ and checked against seaborn 0.13.2. Upstream still labels this interface experimental and incomplete, so prefer it when composition helps and keep conservative production workflows on the function API when needed.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Seaborn Objects Interface.
