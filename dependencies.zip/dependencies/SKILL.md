---
name: dependencies
description: "Guidance and reference for Property Dependencies Guide. Use when a request involves property Dependencies Guide or needs the procedures and examples documented in this source."
---

# Property Dependencies Guide

Deep dive into n8n property dependencies and displayOptions mechanism.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Property Dependencies Guide.
