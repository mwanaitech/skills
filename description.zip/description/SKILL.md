---
name: description
description: "Skills for extracting text from PDFs, scanned documents, images, and other file formats using OCR and document parsing tools."
---

# Description

No additional source instructions were present in the Markdown file.
