---
name: blueprint-spec
description: "Guidance and reference for Render Blueprint Specification. Use when a request involves render Blueprint Specification or needs the procedures and examples documented in this source."
---

# Render Blueprint Specification

Complete reference for render.yaml Blueprint files. Blueprints define your infrastructure as code for reproducible deployments on Render.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Render Blueprint Specification.
