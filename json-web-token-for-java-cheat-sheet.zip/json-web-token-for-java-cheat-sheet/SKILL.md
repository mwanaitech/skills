---
name: json-web-token-for-java-cheat-sheet
description: "Guidance and reference for JSON Web Token Cheat Sheet for Java. Use when a request involves jSON Web Token Cheat Sheet for Java or needs the procedures and examples documented in this source."
---

# JSON Web Token Cheat Sheet for Java

Many applications use **JSON Web Tokens** (JWT) to allow the client to indicate its identity for further exchange after authentication.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving JSON Web Token Cheat Sheet for Java.
