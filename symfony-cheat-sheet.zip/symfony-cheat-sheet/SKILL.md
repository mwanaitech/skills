---
name: symfony-cheat-sheet
description: "Guidance and reference for Symfony Cheat Sheet. Use when a request involves symfony Cheat Sheet or needs the procedures and examples documented in this source."
---

# Symfony Cheat Sheet

This cheat sheet aims to provide developers with security tips when building applications using the Symfony framework. It covers common vulnerabilities and best practices to ensure that your Symfony applications are secure.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Symfony Cheat Sheet.
