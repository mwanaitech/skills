---
name: webhook-processing
description: "Guidance and reference for Webhook Processing Pattern. Use when a request involves webhook Processing Pattern or needs the procedures and examples documented in this source."
---

# Webhook Processing Pattern

**Use Case**: Receive HTTP requests from external systems and process them instantly.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Webhook Processing Pattern.
