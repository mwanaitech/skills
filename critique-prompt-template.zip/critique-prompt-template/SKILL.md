---
name: critique-prompt-template
description: "Guidance and reference for Critique Prompt Template. Use when a request involves critique Prompt Template or needs the procedures and examples documented in this source."
---

# Critique Prompt Template

Review each hypothesis card critically.

For each card:
- Point out unsupported claims.
- Flag overfitting and execution realism risks.
- Check whether kill criteria are objective and measurable.
- Suggest a tighter minimum viable experiment when possible.

Return concise critique bullets per hypothesis_id.
