---
name: javascript-typescript-react-web-frontend-security
description: "Guidance and reference for React (JavaScript/TypeScript) Web Security Spec (React 19.x, TypeScript 5.x). Use when a request involves react (JavaScript/TypeScript) Web Security Spec (React 19.x, TypeScript 5.x) or needs the procedures and examples documented in this source."
---

# React (JavaScript/TypeScript) Web Security Spec (React 19.x, TypeScript 5.x)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving React (JavaScript/TypeScript) Web Security Spec (React 19.x, TypeScript 5.x).
