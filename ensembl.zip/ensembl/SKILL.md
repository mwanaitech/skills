---
name: ensembl
description: "Guidance and reference for Ensembl REST API. Use when a request involves ensembl REST API or needs the procedures and examples documented in this source."
---

# Ensembl REST API

For the Ensembl Genomes (plants, fungi, bacteria, protists, metazoa): (Same base; Ensembl Genomes was merged into the main REST API.)

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Ensembl REST API.
