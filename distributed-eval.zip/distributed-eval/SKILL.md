---
name: distributed-eval
description: "Guidance and reference for Distributed Evaluation. Use when a request involves distributed Evaluation or needs the procedures and examples documented in this source."
---

# Distributed Evaluation

Guide to running evaluation across multiple GPUs using data parallelism and tensor/pipeline parallelism.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Distributed Evaluation.
