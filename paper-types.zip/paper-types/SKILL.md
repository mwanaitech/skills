---
name: paper-types
description: "Guidance and reference for Paper Types Beyond Empirical ML. Use when a request involves paper Types Beyond Empirical ML or needs the procedures and examples documented in this source."
---

# Paper Types Beyond Empirical ML

Guide for writing non-standard paper types: theory papers, survey/tutorial papers, benchmark/dataset papers, and position papers. Each type has distinct structure, evidence standards, and venue expectations.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Paper Types Beyond Empirical ML.
