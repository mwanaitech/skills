---
name: refactoring
description: "Guidance and reference for Refactor Candidates. Use when a request involves refactor Candidates or needs the procedures and examples documented in this source."
---

# Refactor Candidates

After TDD cycle, look for:

- **Duplication** → Extract function/class
- **Long methods** → Break into private helpers (keep tests on public interface)
- **Shallow modules** → Combine or deepen
- **Feature envy** → Move logic to where data lives
- **Primitive obsession** → Introduce value objects
- **Existing code** the new code reveals as problematic
