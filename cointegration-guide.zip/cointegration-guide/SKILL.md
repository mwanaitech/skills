---
name: cointegration-guide
description: "Guidance and reference for Cointegration Testing Guide. Use when a request involves cointegration Testing Guide or needs the procedures and examples documented in this source."
---

# Cointegration Testing Guide

Imagine two drunk people walking home from a bar. They're both stumbling randomly, but one person has a dog on a leash. The person and the dog may wander in different directions temporarily, but the leash keeps them together in the long run. They are "cointegrated."

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Cointegration Testing Guide.
