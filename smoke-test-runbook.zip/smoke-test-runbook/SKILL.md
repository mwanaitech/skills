---
name: smoke-test-runbook
description: "Guidance and reference for Parabolic Short — Live API Smoke Test Runbook. Use when a request involves parabolic Short — Live API Smoke Test Runbook or needs the procedures and examples documented in this source."
---

# Parabolic Short — Live API Smoke Test Runbook

This runbook is the manual verification procedure for the `parabolic-short-trade-planner` skill against **live** FMP and Alpaca APIs. The Phase 1 + Phase 2 unit-test suite (137 tests on dry-run fixtures) cannot prove that the wire shapes upstream still match the contract Phase 1 was built against, nor that the Alpaca paper account is reachable with the configured credentials. This runbook closes that gap.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Parabolic Short — Live API Smoke Test Runbook.
