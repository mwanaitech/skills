---
name: methodology
description: "Guidance and reference for Statistical Arbitrage and Pair Trading Methodology. Use when a request involves statistical Arbitrage and Pair Trading Methodology or needs the procedures and examples documented in this source."
---

# Statistical Arbitrage and Pair Trading Methodology

Pair trading is a market-neutral trading strategy that involves simultaneously buying and selling two highly correlated securities. The strategy profits from the convergence of prices when the relationship between the two stocks temporarily diverges from its historical equilibrium.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Statistical Arbitrage and Pair Trading Methodology.
