---
name: visual-effects
description: "Guidance and reference for Visual Effects. Use when a request involves visual Effects or needs the procedures and examples documented in this source."
---

# Visual Effects

The scale factor (0.005 etc.) is critical:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Visual Effects.
