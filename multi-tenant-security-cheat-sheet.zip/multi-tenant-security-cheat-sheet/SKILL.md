---
name: multi-tenant-security-cheat-sheet
description: "Guidance and reference for Multi-Tenant Application Security Cheat Sheet. Use when a request involves multi-Tenant Application Security Cheat Sheet or needs the procedures and examples documented in this source."
---

# Multi-Tenant Application Security Cheat Sheet

Multi-tenant applications serve multiple customers (tenants) from a shared infrastructure, codebase, and often shared databases. This architecture is the foundation of modern SaaS platforms, offering cost efficiency and simplified operations.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Multi-Tenant Application Security Cheat Sheet.
