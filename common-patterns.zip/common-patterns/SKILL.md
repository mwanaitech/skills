---
name: common-patterns
description: "Guidance and reference for Common Patterns. Use when a request involves common Patterns or needs the procedures and examples documented in this source."
---

# Common Patterns

Component properties (TEXT, BOOLEAN, INSTANCE_SWAP) MUST be added inside the per-variant loop, BEFORE `combineAsVariants`. The component set inherits them from its children.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Common Patterns.
