---
name: ai-agent-security-cheat-sheet
description: "Guidance and reference for AI Agent Security Cheat Sheet. Use when a request involves aI Agent Security Cheat Sheet or needs the procedures and examples documented in this source."
---

# AI Agent Security Cheat Sheet

AI agents are autonomous systems powered by Large Language Models (LLMs) that can reason, plan, use tools, maintain memory, and take actions to accomplish goals. This expanded capability introduces unique security risks beyond traditional LLM prompt injection. This cheat sheet provides best practices to secure AI agent architectures and minimize attack surfaces.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving AI Agent Security Cheat Sheet.
