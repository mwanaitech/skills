---
name: rule-template
description: "Guidance and reference for Rule Template Skeleton. Use when a request involves rule Template Skeleton or needs the procedures and examples documented in this source."
---

# Rule Template Skeleton

## Figma MCP Integration Rules

- Required flow (`get_design_context` -> `get_screenshot`)
- Implementation conventions for this repo
- Asset handling
- Validation requirements

## Project-Specific Conventions

- Components path(s)
- Token source(s)
- Styling system
- Testing and accessibility expectations
