---
name: network-patterns
description: "Guidance and reference for TouchDesigner Network Patterns. Use when a request involves touchDesigner Network Patterns or needs the procedures and examples documented in this source."
---

# TouchDesigner Network Patterns

Complete network recipes for common creative coding tasks. Each pattern shows the operator chain, MCP tool calls to build it, and key parameter settings.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving TouchDesigner Network Patterns.
