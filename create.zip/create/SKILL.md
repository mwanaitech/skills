---
name: create
description: "Guidance and reference for Task. Use when a request involves task or needs the procedures and examples documented in this source."
---

# Task

Invoke `slides` skill to create persuasive HTML slides using design tokens, Chart.js, and the slide knowledge database.

## Task
<task>$ARGUMENTS</task>
