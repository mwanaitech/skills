---
name: interactive-api-docs
description: "Guidance and reference for Interactive API Documentation. Use when a request involves interactive API Documentation or needs the procedures and examples documented in this source."
---

# Interactive API Documentation

**GraphQL Playground:**

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Interactive API Documentation.
