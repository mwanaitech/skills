---
name: function-reference
description: "Guidance and reference for Seaborn Function Reference. Use when a request involves seaborn Function Reference or needs the procedures and examples documented in this source."
---

# Seaborn Function Reference

This document provides a comprehensive reference for all major seaborn functions, organized by category. It is updated for seaborn 0.13.2 patterns.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Seaborn Function Reference.
