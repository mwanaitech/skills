---
name: interpretation-framework
description: "Guidance and reference for Institutional Flow Interpretation Framework. Use when a request involves institutional Flow Interpretation Framework or needs the procedures and examples documented in this source."
---

# Institutional Flow Interpretation Framework

This framework provides a systematic approach to interpreting institutional ownership changes and converting 13F filing data into actionable investment signals. Use this as a decision tree for analyzing stocks discovered through institutional flow tracking.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Institutional Flow Interpretation Framework.
