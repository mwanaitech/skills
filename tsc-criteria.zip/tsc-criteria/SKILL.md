---
name: tsc-criteria
description: "Guidance and reference for Trust Services Criteria -- Detailed Scoring and Evidence Tables. Use when a request involves trust Services Criteria -- Detailed Scoring and Evidence Tables or needs the procedures and examples documented in this source."
---

# Trust Services Criteria -- Detailed Scoring and Evidence Tables

This file contains the detailed Trust Services Criteria evaluation questions, evidence requirements, common gaps, scoring templates, and evidence mapping for the SOC 2 Type II Readiness Gap Analysis skill. See [SKILL.md](SKILL.md) for the main skill definition, process overview, and output format.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Trust Services Criteria -- Detailed Scoring and Evidence Tables.
