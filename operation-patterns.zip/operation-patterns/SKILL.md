---
name: operation-patterns
description: "Guidance and reference for Operation Patterns Guide. Use when a request involves operation Patterns Guide or needs the procedures and examples documented in this source."
---

# Operation Patterns Guide

Common node configuration patterns organized by node type and operation.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Operation Patterns Guide.
