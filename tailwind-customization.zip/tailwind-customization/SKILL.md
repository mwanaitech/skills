---
name: tailwind-customization
description: "Guidance and reference for Tailwind CSS Customization. Use when a request involves tailwind CSS Customization or needs the procedures and examples documented in this source."
---

# Tailwind CSS Customization

Config file structure, custom utilities, plugins, and theme extensions.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Tailwind CSS Customization.
