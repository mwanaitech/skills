---
name: tool-rules
description: "Guidance and reference for IaC Security -- Tool-Specific Rule Sets and Detection Patterns. Use when a request involves iaC Security -- Tool-Specific Rule Sets and Detection Patterns or needs the procedures and examples documented in this source."
---

# IaC Security -- Tool-Specific Rule Sets and Detection Patterns

This file contains the detailed tool-specific rule sets, detection patterns, and remediation examples for the Infrastructure as Code Security Review skill. See [SKILL.md](SKILL.md) for the main skill definition, process overview, and output format.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving IaC Security -- Tool-Specific Rule Sets and Detection Patterns.
