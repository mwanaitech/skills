---
name: python-django-web-server-security
description: "Guidance and reference for Django (Python) Web Security Spec (Django 6.0.x, Python 3.x). Use when a request involves django (Python) Web Security Spec (Django 6.0.x, Python 3.x) or needs the procedures and examples documented in this source."
---

# Django (Python) Web Security Spec (Django 6.0.x, Python 3.x)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Django (Python) Web Security Spec (Django 6.0.x, Python 3.x).
