---
name: javascript-jquery-web-frontend-security
description: "Guidance and reference for jQuery Frontend Security Spec (jQuery 4.0.x, modern browsers). Use when a request involves jQuery Frontend Security Spec (jQuery 4.0.x, modern browsers) or needs the procedures and examples documented in this source."
---

# jQuery Frontend Security Spec (jQuery 4.0.x, modern browsers)

This document is designed as a **security spec** that supports:

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving jQuery Frontend Security Spec (jQuery 4.0.x, modern browsers).
