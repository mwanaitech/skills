---
name: artifacts
description: "Guidance and reference for Pricing Strategy & Optimization - Frameworks, Templates & Checklists. Use when a request involves pricing Strategy & Optimization - Frameworks, Templates & Checklists or needs the procedures and examples documented in this source."
---

# Pricing Strategy & Optimization - Frameworks, Templates & Checklists

*112 artifacts extracted from Lenny's Podcast and Newsletter*

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Pricing Strategy & Optimization - Frameworks, Templates & Checklists.
