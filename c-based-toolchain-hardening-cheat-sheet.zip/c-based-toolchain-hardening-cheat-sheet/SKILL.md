---
name: c-based-toolchain-hardening-cheat-sheet
description: "Guidance and reference for C-Based Toolchain Hardening Cheat Sheet. Use when a request involves c-Based Toolchain Hardening Cheat Sheet or needs the procedures and examples documented in this source."
---

# C-Based Toolchain Hardening Cheat Sheet

C-Based Toolchain Hardening is a treatment of project settings that will help you deliver reliable and secure code when using C, C++ and Objective C languages in a number of development environments. This article will examine Microsoft and GCC toolchains for the C, C++ and Objective C languages. It will guide you through the steps you should take to create executables with firmer defensive postures and increased integration with the available platform security. Effectively configuring the toolchain also means your project will enjoy a number of benefits during development, including enhanced warnings and static analysis, and self-debugging code.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving C-Based Toolchain Hardening Cheat Sheet.
