---
name: finviz-screener-filters
description: "Guidance and reference for FinViz Screener Filter Reference. Use when a request involves finViz Screener Filter Reference or needs the procedures and examples documented in this source."
---

# FinViz Screener Filter Reference

This reference maps FinViz screener filter codes to their meanings and natural-language keywords (English + Japanese). Claude uses this document to translate user intent into valid FinViz filter codes.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving FinViz Screener Filter Reference.
