---
name: basic-markdown
description: "Guidance and reference for Basic writing and formatting syntax. Use when a request involves basic writing and formatting syntax or needs the procedures and examples documented in this source."
---

# Basic writing and formatting syntax

Create sophisticated formatting for your prose and code on GitHub with simple syntax.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Basic writing and formatting syntax.
