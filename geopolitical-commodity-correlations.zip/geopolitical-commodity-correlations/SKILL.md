---
name: geopolitical-commodity-correlations
description: "Guidance and reference for Geopolitical Events and Commodity Correlations. Use when a request involves geopolitical Events and Commodity Correlations or needs the procedures and examples documented in this source."
---

# Geopolitical Events and Commodity Correlations

**Middle East Conflicts:**

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Geopolitical Events and Commodity Correlations.
