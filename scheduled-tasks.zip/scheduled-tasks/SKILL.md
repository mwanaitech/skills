---
name: scheduled-tasks
description: "Guidance and reference for Scheduled Tasks Pattern. Use when a request involves scheduled Tasks Pattern or needs the procedures and examples documented in this source."
---

# Scheduled Tasks Pattern

**Use Case**: Recurring automation workflows that run automatically on a schedule.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Scheduled Tasks Pattern.
