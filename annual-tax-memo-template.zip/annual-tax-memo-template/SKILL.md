---
name: annual-tax-memo-template
description: "Guidance and reference for Annual Dividend Tax Planning Memo Template. Use when a request involves annual Dividend Tax Planning Memo Template or needs the procedures and examples documented in this source."
---

# Annual Dividend Tax Planning Memo Template

```markdown
# Annual Dividend Tax Planning Memo ([Year])

## Filing Timeline
- Tax year:
- Filing deadline:
- Extension status (filed/planned/not needed):
- Expected filing date:

## Scope
- Accounts included:
- Holdings covered:
- Data sources used:

## Assumptions
- Rule set version/date:
- Missing data assumptions:

## Distribution Classification Summary
| Ticker | Account | Ordinary (est.) | Qualified (est.) | REIT/other components | Confidence |
|---|---|---:|---:|---|---|
| ... | ... | ... | ... | ... | High/Med/Low |

## Account-Location Actions
| Ticker | Current location | Proposed location | Reason |
|---|---|---|---|
| ... | ... | ... | ... |

## Open Risks / Follow-Ups
1. ...
2. ...
3. ...

## Advisor Questions
1. ...
2. ...
```

Keep the memo concise and assumption-driven.
