---
name: anthropic-best-practices
description: "Guidance and reference for Skill authoring best practices. Use when a request involves skill authoring best practices or needs the procedures and examples documented in this source."
---

# Skill authoring best practices

Good Skills are concise, well-structured, and tested with real usage. This guide provides practical authoring decisions to help you write Skills that agents can discover and use effectively.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Skill authoring best practices.
