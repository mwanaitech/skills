---
name: trusted-news-sources
description: "Guidance and reference for Trusted News Sources for Market Analysis. Use when a request involves trusted News Sources for Market Analysis or needs the procedures and examples documented in this source."
---

# Trusted News Sources for Market Analysis

**Federal Reserve:**

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Trusted News Sources for Market Analysis.
