---
name: reference
description: "Guidance and reference for PDF Processing Advanced Reference. Use when a request involves pDF Processing Advanced Reference or needs the procedures and examples documented in this source."
---

# PDF Processing Advanced Reference

This document contains advanced PDF processing features, detailed examples, and additional libraries not covered in the main skill instructions.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving PDF Processing Advanced Reference.
