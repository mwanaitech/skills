---
name: http-api-integration
description: "Guidance and reference for HTTP API Integration Pattern. Use when a request involves hTTP API Integration Pattern or needs the procedures and examples documented in this source."
---

# HTTP API Integration Pattern

**Use Case**: Fetch data from REST APIs, transform it, and use it in workflows.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving HTTP API Integration Pattern.
