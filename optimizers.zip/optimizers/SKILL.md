---
name: optimizers
description: "Guidance and reference for DSPy Optimizers (Teleprompters). Use when a request involves dSPy Optimizers (Teleprompters) or needs the procedures and examples documented in this source."
---

# DSPy Optimizers (Teleprompters)

Complete guide to DSPy's optimization algorithms for improving prompts and model weights.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving DSPy Optimizers (Teleprompters).
