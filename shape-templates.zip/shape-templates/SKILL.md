---
name: shape-templates
description: "Guidance and reference for Shape Templates for Favicons. Use when a request involves shape Templates for Favicons or needs the procedures and examples documented in this source."
---

# Shape Templates for Favicons

Industry-specific shapes and custom favicon templates beyond basic circles and squares.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Shape Templates for Favicons.
