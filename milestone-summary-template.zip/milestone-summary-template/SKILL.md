---
name: milestone-summary-template
description: "Guidance and reference for Milestone Summary Template. Use when a request involves milestone Summary Template or needs the procedures and examples documented in this source."
---

# Milestone Summary Template

Use this when completing major phases or milestones.

```markdown
## Phase [N] Complete: [Date]

### Accomplishments
- [Major item delivered]
- [Major item delivered]

### Deliverables
- <mention-page url="...">Deliverable 1</mention-page>
- [Link to PR/deployment]

### Metrics
- [Relevant metric]
- [Relevant metric]

### Learnings
- [What went well]
- [What to improve]

### Next Phase
Starting [Phase name] on [Date]
```
