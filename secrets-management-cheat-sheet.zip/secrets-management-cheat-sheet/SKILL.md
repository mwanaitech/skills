---
name: secrets-management-cheat-sheet
description: "Guidance and reference for Secrets Management Cheat Sheet. Use when a request involves secrets Management Cheat Sheet or needs the procedures and examples documented in this source."
---

# Secrets Management Cheat Sheet

Secrets are being used everywhere nowadays, especially with the popularity of the DevOps movement. Application Programming Interface (API) keys, database credentials, Identity and Access Management (IAM) permissions, Secure Shell (SSH) keys, certificates, etc. Many organizations have them hardcoded within the source code in plaintext, littered throughout configuration files and configuration management tools.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Secrets Management Cheat Sheet.
