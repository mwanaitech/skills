---
name: crud-operations
description: "Guidance and reference for CRUD Operations with CloudBase. Use when a request involves cRUD Operations with CloudBase or needs the procedures and examples documented in this source."
---

# CRUD Operations with CloudBase

This document covers Create, Update, and Delete operations for CloudBase document database.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving CRUD Operations with CloudBase.
