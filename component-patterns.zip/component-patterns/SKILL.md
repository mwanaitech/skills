---
name: component-patterns
description: "Guidance and reference for Component & Variant API Patterns. Use when a request involves component & Variant API Patterns or needs the procedures and examples documented in this source."
---

# Component & Variant API Patterns

`figma.createComponent()` returns a `ComponentNode`, which behaves like a `FrameNode` but can be published, instanced, and combined into variant sets.

## Reference material

Read `references/source.md` for the complete source guidance, procedures, and examples when handling a task involving Component & Variant API Patterns.
